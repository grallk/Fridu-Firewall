#!/bin/bash
# Modification du Firewall apres avoir �diter les nouvelles regles
# 
### Installation des r�gles  -  dossier par d�faut /home/elgo/VM-Firewall/  
/usr/local/VM-Firewall/install.sh template=nixi2


### Arr�t/D�marrage du FW  - (dossier par défaut /home/elgo/VM-Firewall/scripts)
/usr/local/VM-Firewall/scripts/Fridu-firewall.script stop
/usr/local/VM-Firewall/scripts/Fridu-firewall.script start verbose=1 dump=dumpfile


### Voir les zones du FW  -  (dossier par défaut  - /home/elgo/VM-Firewall/scripts/
/usr/local/VM-Firewall/scripts/Fridu-firewall.script display
